function setup() {
  colorMode(HSL);
  createCanvas(400, 400);
}

function draw() {
  background(168,47,24);
  push();
  setCenter(200,200);
  noStroke();
  fill(194,23,90);
  polarPolygon(25,0,100,0);
  polarSquare(0,50,-70);
  fill(168,47,24);
  polarTriangle(140,75,140);
  polarTriangle(-140,75,140);
  pop();
  fill(20);
  ellipse(150,220,50);
  ellipse(250,220,50);
  fill(44,68,62);
  push();
  setCenter(150,220);
  polarEllipse(0,15,17,0)
  pop();
  push();
  setCenter(250,220);
  polarEllipse(0,15,17,0)
  pop();
  push();
  setCenter(200,220);
  stroke(20);
  polarLine(90,30,0);
  pop();
  push();
  setCenter(230,270);
  stroke(20);
  polarLine(40,45,0);
  pop();
  push();
  setCenter(170,270);
  stroke(20);
  polarLine(-40,45,0);
  pop();
  setCenter(200,200);
  fill(175,47,49,.80);
  polarPentagons(10,70,200);
}