let R = 10;
let G = 20;
let B = 30;
let x;
let y;
let gridspace = 25;
let num=16;
function setup() {
  colorMode(RGB);
  createCanvas(400, 400);
  background(220);
}
function draw() {
  noStroke();
  square(mouseX,mouseY,30);
  for(x=10;x<width;x+=gridspace){
    ellipse(x,20,10);
  }
  for(x=10;x<width;x+=gridspace){
    ellipse(x,395,10);
  }
  y=20;
  for(let i=0;i<=num;i++){
    ellipse(10,y,10);
    y+=gridspace;
  }
  y=20;
  for(let i = 0;i<=num;i++){
    ellipse(385,y,10);
    y+=gridspace;
  }
if(mouseX>400){
    background(220);
  }
}
function mousePressed() {
  fill(R,G,B);
}
function mouseReleased(){
  fill(220,220,220,0);
}
function mouseClicked(){
  if(R<=255){
    R=R+15;
  }
  if(R>255){
    R = 10;
  }
  if(G<=255){
    G=G+25;
  }
  if(G>255){
    G = 20;
  }
  if(B<=255){
    B=B+50;
  }
  if(B>255){
    B=30;
  }
}

