let snakeX = [];
let snakeY = [];
let i;
let num = 10;
let applePic;
//let appleMovement = [];
function setup() {
  createCanvas(600, 600);
  colorMode(RGB);
  angleMode(DEGREES);
  frameRate(60);
  let appleArray = [];
  let applePic = drawApple(appleArray);
  //let appleX = 0;
  //let appleY = 0;
  //appleMovement[0] = apples(appleX);
  //appleMovement[1]= apples(appleY);
  //print(appleMovement);
  print(applePic);
}

function draw() {
  background(53, 102, 79);
  push();
  for (i=num-1;i>0;i--){
    snakeX[i] = snakeX[i-1];
    snakeY[i] = snakeY[i-1];
  }
  snakeX[0] = mouseX;
  snakeY[0] = mouseY;
  for(i=0;i<num;i++){
    noStroke();
    fill(88, 184, 79);
    ellipse(snakeX[i],snakeY[i],25);
  }
  translate(mouseX,mouseY);
  noStroke();
  fill(88, 184, 79);
  ellipse(0,0,25);
  stroke(209, 71, 50);
  line(-13,0,-25,0);
  noStroke();
  fill(0);
  rect(-5,-12,10,5);
  rect(-5,7,10,5);
  pop();
  for(i=0;i<num;i++){
    translate(100,120);
    scale(1.5);
    drawApple();
  }
}

function drawApple(ellipseApple){
  ellipseApple = [0,0,10,20];
  noStroke();
  fill(0);
  rect(ellipseApple[0]-2,ellipseApple[1]-8,5,10);
  push();
  rotate(45);
  noStroke();
  fill(168, 60, 54);
  ellipse(ellipseApple[0]+4,ellipseApple[1],ellipseApple[2],ellipseApple[3]);
  pop();
  push();
  noStroke();
  fill(168, 60, 54);
  rotate(-45);
  ellipse(ellipseApple[0]-4,ellipseApple[1],ellipseApple[2],ellipseApple[3]);
  pop();
  return ellipseApple
}
/**
function apples(appleX,appleY){
  appleX = int(random(100,300));
  appleY = int(random(100,300));
  return(appleX,appleY);
}
**/