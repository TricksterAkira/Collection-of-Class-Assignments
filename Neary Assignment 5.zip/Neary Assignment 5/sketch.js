function setup() {
  createCanvas(600, 600);
  colorMode(RGB);
  background(209,240,231,94);
  noFill();
  strokeWeight(50);
  stroke(160);
  square(0,0,600);
  //task bar;
  noStroke();
  fill(182,220,242,180);
  rect(25,540,551,35);
  //first button;
  stroke(100);
  strokeWeight(2);
  fill(82,149,152,175);
  ellipse(50,558,28);
  //second button,uses key pressed
  fill(82,149,152);
  rect(35,50,35,30);
  //other "app" icons
  fill(98,181,158,195);
  rect(35,90,35,30);
  rect(80,50,35,30);
  rect(35,130,35,30);
  rect(125,50,35,30);
  //third button
  fill(82,149,152,210);
  rect(80,90,35,30);
}
function mouseClicked(){
  if(mouseX<=78 && mouseX>=22 && mouseY>=530 && mouseY<=586){
    //window
    stroke(100);
    fill(98,181,158,150);
    rect(50,300,100,230);
    //window details
    fill(159,214,160,150);
    rect(55,320,25,35);
    rect(55,450,90,35);
    fill(114,211,151);
    rect(55,400,90,35);
    rect(85,320,60,35);
    fill(245);
    noStroke();
    textSize(14);
    text("hello :D",79,422);
  }
  if(mouseX>=80 && mouseX<=115 && mouseY>=90 && mouseY<=120){
    stroke(100);
    fill(98,181,158,185);
    rect(365,45,155,85,5);
    fill(159,214,160);
    rect(380,62,55,50);
    beginShape();
    vertex(450,80);
    vertex(460,85);
    vertex(450,90);
    vertex(450,80);
    endShape();
    rect(460,77,5,15);
    rect(468,77,5,15);
     }
}
function draw(){
  if(keyIsDown(70)===true && mouseX>=35 && mouseX<=70 && mouseY>=50 && mouseY<=80){
    //browser window
    fill(182,220,242);
    stroke(100);
    rect(160,150,400,300);
    fill(159,214,160);
    rect(170,180,380,270);
    line(530,160,550,175);
    line(530,175,550,160);
    noStroke();
    fill(245);
    textSize(12);
    text('My friend told me to put fortnite in the browser so,',230,240);
    stroke(245);
    textSize(20);
    text('FORTNITE',305,300);
  }
}